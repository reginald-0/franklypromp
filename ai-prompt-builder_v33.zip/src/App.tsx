"use client"

import type React from "react"
import { useState } from "react"
import HomeTab from "./components/HomeTab"
import HistoryTab from "./components/HistoryTab"
import SettingsTab from "./components/SettingsTab"
import Header from "./components/Header"
import "./App.css"

type Tab = "home" | "history" | "settings"

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>("home")

  const handleNavigateToHistory = () => {
    setActiveTab("history")
  }

  const handleMinimize = () => {
    console.log("Minimize clicked")
    // In a real extension, this would minimize the popup
  }

  const handleClose = () => {
    console.log("Close clicked")
    // In a real extension, this would close the popup
  }

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <HomeTab onNavigateToHistory={handleNavigateToHistory} />
      case "history":
        return <HistoryTab />
      case "settings":
        return <SettingsTab />
      default:
        return <HomeTab onNavigateToHistory={handleNavigateToHistory} />
    }
  }

  // Determine container height based on active tab
  const containerHeight = activeTab === "history" ? "h-[85vh]" : "h-[780px]"

  return (
    <div
      className={`flex flex-col ${containerHeight} w-[350px] bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300`}
    >
      {/* Consistent header across all tabs */}
      <Header onMinimize={handleMinimize} onClose={handleClose} />

      {/* Tab content */}
      <div className="flex-1 overflow-hidden">{renderContent()}</div>

      {/* Navigation footer */}
      <div className="flex justify-around items-center py-1.5 border-t border-gray-200">
        <button
          onClick={() => setActiveTab("home")}
          className={`flex flex-col items-center px-4 py-1 rounded-lg ${activeTab === "home" ? "text-blue-600" : "text-gray-400"}`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mb-0.5"
          >
            <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
            <polyline points="9 22 9 12 15 12 15 22"></polyline>
          </svg>
          <span className="text-xs mt-0.5">Home</span>
        </button>

        <button
          onClick={() => setActiveTab("history")}
          className={`flex flex-col items-center px-4 py-1 rounded-lg ${activeTab === "history" ? "text-blue-600" : "text-gray-400"}`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mb-0.5"
          >
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
          <span className="text-xs mt-0.5">History</span>
        </button>

        <button
          onClick={() => setActiveTab("settings")}
          className={`flex flex-col items-center px-4 py-1 rounded-lg ${activeTab === "settings" ? "text-blue-600" : "text-gray-400"}`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mb-0.5"
          >
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          <span className="text-xs mt-0.5">Settings</span>
        </button>
      </div>
    </div>
  )
}

export default App
