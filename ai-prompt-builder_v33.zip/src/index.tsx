import React from "react"
import ReactDOM from "react-dom/client"
import App from "./App"
import "./App.css"

// Make sure we have a root element in the HTML
const rootElement = document.getElementById("root")

if (!rootElement) {
  // Create root element if it doesn't exist
  const root = document.createElement("div")
  root.id = "root"
  document.body.appendChild(root)
}

const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement)

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
