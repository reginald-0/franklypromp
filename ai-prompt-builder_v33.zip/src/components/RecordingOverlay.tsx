"use client"

import type React from "react"
import { useState, useEffect } from "react"
import RecordingSidebar from "./RecordingSidebar"

interface RecordingOverlayProps {
  onCancel: () => void
  onComplete: () => void
}

const RecordingOverlay: React.FC<RecordingOverlayProps> = ({ onCancel, onComplete }) => {
  const [countdown, setCountdown] = useState(3)
  const [isRecording, setIsRecording] = useState(false)
  const [screenshots, setScreenshots] = useState<string[]>([])

  // Handle countdown and start recording
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1)
      }, 1000)
      return () => clearTimeout(timer)
    } else if (countdown === 0) {
      // Start recording after countdown
      setIsRecording(true)
    }
  }, [countdown])

  // Handle screenshot capture
  const handleScreenshot = () => {
    // In a real implementation, this would capture the actual screen
    // For now, we'll just add a placeholder
    const newScreenshot = `/placeholder.svg?height=720&width=1280&query=screenshot ${screenshots.length + 1}`
    setScreenshots([...screenshots, newScreenshot])
  }

  // Handle recording completion
  const handleComplete = () => {
    setIsRecording(false)
    onComplete()
  }

  return (
    <div className="fixed inset-0 z-50 bg-white">
      {/* Countdown overlay */}
      {countdown > 0 && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center">
            <span className="text-4xl font-bold text-indigo-600">{countdown}</span>
          </div>
        </div>
      )}

      {/* Recording overlay */}
      {isRecording && (
        <>
          {/* Semi-transparent overlay for annotation mode */}
          <div className="fixed inset-0 bg-black bg-opacity-5 pointer-events-none"></div>

          {/* Recording sidebar */}
          <RecordingSidebar onCancel={onCancel} onComplete={handleComplete} onScreenshot={handleScreenshot} />
        </>
      )}
    </div>
  )
}

export default RecordingOverlay
