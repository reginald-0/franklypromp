"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import MediaFilesTab from "./media/MediaFilesTab"
import type { MediaFile } from "./media/MediaFilesTab"

interface NewSessionDetailsProps {
  onBack: () => void
}

type LoadingStage = "upload" | "processing" | "delivery" | "completion" | "done"

const NewSessionDetails: React.FC<NewSessionDetailsProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<"prompt" | "media">("prompt")
  const [loadingStage, setLoadingStage] = useState<LoadingStage>("upload")
  const [progress, setProgress] = useState(0)
  const [isEditing, setIsEditing] = useState(false)
  const [promptText, setPromptText] = useState("")
  const [editText, setEditText] = useState("")
  const [displayedText, setDisplayedText] = useState("")
  const [copySuccess, setCopySuccess] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const typewriterRef = useRef<NodeJS.Timeout | null>(null)

  // Sample media files for demonstration
  const sampleMediaFiles: MediaFile[] = [
    {
      id: "audio-1",
      type: "audio",
      filename: "recording-1.mp3",
      filesize: "1.2 MB",
      url: "/sound-waves-abstract.png",
      duration: "0:45",
    },
    {
      id: "screenshot-1",
      type: "screenshot",
      filename: "screenshot-1.png",
      filesize: "345 KB",
      url: "/computer-screenshot.png",
    },
    {
      id: "annotation-1",
      type: "annotation",
      filename: "annotation-1.svg",
      filesize: "12 KB",
      url: "/annotated-manuscript.png",
    },
  ]

  // Sample generated text
  const generatedText = `The navbar should have a gradient background that transitions smoothly from dark blue to light blue. The logo should be centered with navigation links evenly distributed on either side. Each link should have a subtle hover effect that enlarges the text slightly and changes its color to white.

The dropdown menus should appear with a fade-in animation and have slightly rounded corners. All buttons in the UI should maintain consistent styling with a 4px border radius and the primary action buttons should use our brand color #3B82F6.

When users scroll down, the navbar should become slightly translucent, showing a hint of the content behind it, while maintaining readability of the navigation items.`

  // Loading stage messages and icons
  const loadingStages = {
    upload: {
      message: "Sending recording files for analysis...",
      color: "text-blue-500",
      bgColor: "bg-blue-100",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="32"
          height="32"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-blue-500"
        >
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="17 8 12 3 7 8" />
          <line x1="12" y1="3" x2="12" y2="15" />
        </svg>
      ),
      progress: 25,
    },
    processing: {
      message: "LLMs are oogling your masterful feedback...",
      color: "text-purple-500",
      bgColor: "bg-purple-100",
      icon: <div className="text-3xl">🧠</div>,
      progress: 50,
    },
    delivery: {
      message: "Butlers are speeding over with your requested text...",
      color: "text-green-500",
      bgColor: "bg-green-100",
      icon: <div className="text-3xl">🏃</div>,
      progress: 75,
    },
    completion: {
      message: "Presto!",
      color: "text-amber-500",
      bgColor: "bg-amber-100",
      icon: <div className="text-3xl">✨</div>,
      progress: 100,
    },
    done: {
      message: "",
      color: "",
      bgColor: "",
      icon: null,
      progress: 100,
    },
  }

  // Format text for display (handle bold, lists, etc.)
  const formatTextForDisplay = (text: string) => {
    // Process the text line by line
    return text.split("\n").map((line, index) => {
      // Handle bold text
      const formattedLine = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")

      // Check if line is a bullet list item
      if (line.trim().startsWith("- ")) {
        return (
          <li key={index} className="ml-5 list-disc">
            <span dangerouslySetInnerHTML={{ __html: formattedLine.substring(2) }} />
          </li>
        )
      }

      // Check if line is a numbered list item
      const numberedListMatch = line.trim().match(/^(\d+)\.\s(.*)/)
      if (numberedListMatch) {
        return (
          <li key={index} className="ml-5 list-decimal">
            <span dangerouslySetInnerHTML={{ __html: numberedListMatch[2] }} />
          </li>
        )
      }

      // Regular paragraph
      return (
        <p key={index} className="mb-4">
          <span dangerouslySetInnerHTML={{ __html: formattedLine }} />
        </p>
      )
    })
  }

  // Simulate loading stages
  useEffect(() => {
    if (loadingStage === "upload") {
      setProgress(loadingStages.upload.progress)
      const timer = setTimeout(() => {
        setLoadingStage("processing")
      }, 2500)
      return () => clearTimeout(timer)
    } else if (loadingStage === "processing") {
      setProgress(loadingStages.processing.progress)
      const timer = setTimeout(() => {
        setLoadingStage("delivery")
      }, 2000)
      return () => clearTimeout(timer)
    } else if (loadingStage === "delivery") {
      setProgress(loadingStages.delivery.progress)
      const timer = setTimeout(() => {
        setLoadingStage("completion")
      }, 2000)
      return () => clearTimeout(timer)
    } else if (loadingStage === "completion") {
      setProgress(loadingStages.completion.progress)
      const timer = setTimeout(() => {
        setLoadingStage("done")
        setPromptText(generatedText)
        setEditText(generatedText)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [loadingStage])

  // Typewriter effect for displaying text
  useEffect(() => {
    if (loadingStage === "done" && promptText && displayedText === "") {
      let i = 0
      const speed = 10 // typing speed in ms

      if (typewriterRef.current) {
        clearInterval(typewriterRef.current)
      }

      typewriterRef.current = setInterval(() => {
        if (i < promptText.length) {
          setDisplayedText(promptText.substring(0, i + 1))
          i++
        } else {
          if (typewriterRef.current) {
            clearInterval(typewriterRef.current)
          }
        }
      }, speed)

      return () => {
        if (typewriterRef.current) {
          clearInterval(typewriterRef.current)
        }
      }
    }
    // Remove displayedText from the dependency array to prevent re-triggering the effect
  }, [loadingStage, promptText])

  const handleCopyText = () => {
    navigator.clipboard.writeText(promptText)
    setCopySuccess(true)
    setTimeout(() => setCopySuccess(false), 2000)
  }

  const handleSave = () => {
    setPromptText(editText)
    setDisplayedText(editText) // Show full text immediately after saving
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditText(promptText)
    setIsEditing(false)
  }

  const handleDelete = () => {
    setShowDeleteConfirm(true)
  }

  const confirmDelete = () => {
    // Logic to delete the session would go here
    setShowDeleteConfirm(false)
    onBack() // Return to previous screen after deletion
  }

  const cancelDelete = () => {
    setShowDeleteConfirm(false)
  }

  const applyFormatting = (format: "bold" | "bullet" | "number") => {
    const textarea = textareaRef.current
    if (!textarea) return

    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = editText.substring(start, end)
    let formattedText = ""
    let cursorOffset = 0

    switch (format) {
      case "bold":
        formattedText = `**${selectedText}**`
        cursorOffset = 2
        break
      case "bullet":
        // If we're in the middle of a line, add a newline first
        const beforeSelection = editText.substring(0, start)
        const needsNewline = beforeSelection.length > 0 && !beforeSelection.endsWith("\n")
        formattedText = `${needsNewline ? "\n" : ""}- ${selectedText}`
        cursorOffset = needsNewline ? 3 : 2
        break
      case "number":
        // If we're in the middle of a line, add a newline first
        const beforeSelectionNum = editText.substring(0, start)
        const needsNewlineNum = beforeSelectionNum.length > 0 && !beforeSelectionNum.endsWith("\n")
        formattedText = `${needsNewlineNum ? "\n" : ""}1. ${selectedText}`
        cursorOffset = needsNewlineNum ? 4 : 3
        break
    }

    const newText = editText.substring(0, start) + formattedText + editText.substring(end)
    setEditText(newText)

    // Set focus back to textarea and position cursor
    setTimeout(() => {
      if (textarea) {
        textarea.focus()
        textarea.setSelectionRange(start + cursorOffset, start + cursorOffset + selectedText.length)
      }
    }, 0)
  }

  // Get current date and time
  const getCurrentDateTime = () => {
    const now = new Date()
    const hours = now.getHours().toString().padStart(2, "0")
    const minutes = now.getMinutes().toString().padStart(2, "0")
    return `Today, ${hours}:${minutes} • Just now`
  }

  // Handle smart list continuation
  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter") {
      const textarea = textareaRef.current
      if (!textarea) return

      const cursorPos = textarea.selectionStart
      const textBeforeCursor = editText.substring(0, cursorPos)
      const textAfterCursor = editText.substring(cursorPos)

      // Check if we're in a bullet list
      const bulletListMatch = textBeforeCursor.match(/(?:^|\n)(- .*)$/)
      if (bulletListMatch) {
        const listItem = bulletListMatch[1]

        // If the list item is empty (just "- "), end the list
        if (listItem === "- " || listItem === "-") {
          event.preventDefault()
          const newText = textBeforeCursor.substring(0, textBeforeCursor.length - 2) + "\n" + textAfterCursor
          setEditText(newText)

          // Position cursor after the newline
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos - 1
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        } else {
          // Continue the list with a new bullet point
          event.preventDefault()
          const newText = textBeforeCursor + "\n- " + textAfterCursor
          setEditText(newText)

          // Position cursor after the new bullet point
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos + 3
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        }
        return
      }

      // Check if we're in a numbered list
      const numberedListMatch = textBeforeCursor.match(/(?:^|\n)(\d+)\. (.*)$/)
      if (numberedListMatch) {
        const listNumber = Number.parseInt(numberedListMatch[1])
        const listContent = numberedListMatch[2]

        // If the list item is empty, end the list
        if (listContent.trim() === "") {
          event.preventDefault()
          const newText =
            textBeforeCursor.substring(0, textBeforeCursor.length - (listNumber.toString().length + 2)) +
            "\n" +
            textAfterCursor
          setEditText(newText)

          // Position cursor after the newline
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos - (listNumber.toString().length + 1)
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        } else {
          // Continue the list with the next number
          event.preventDefault()
          const nextNumber = listNumber + 1
          const newText = textBeforeCursor + `\n${nextNumber}. ` + textAfterCursor
          setEditText(newText)

          // Position cursor after the new numbered item
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos + 3 + nextNumber.toString().length
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        }
      }
    } else if (event.key === "Tab") {
      event.preventDefault()
      const textarea = textareaRef.current
      if (!textarea) return

      const start = textarea.selectionStart
      const end = textarea.selectionEnd

      // Insert two spaces at the cursor position
      const newText = editText.substring(0, start) + "  " + editText.substring(end)
      setEditText(newText)

      // Move the cursor to after the inserted spaces
      setTimeout(() => {
        textarea.focus()
        textarea.setSelectionRange(start + 2, start + 2)
      }, 0)
    }
  }

  // Render loading animation
  if (loadingStage !== "done") {
    const currentStage = loadingStages[loadingStage]

    return (
      <div className="flex flex-col h-full bg-white">
        {/* Header */}
        <div className="border-b border-gray-200 p-4">
          <div className="flex items-center mb-1">
            <button onClick={onBack} className="text-gray-500 mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6" />
              </svg>
            </button>
            <h1 className="text-lg font-medium">New Session</h1>
          </div>
          <p className="text-xs text-gray-500">{getCurrentDateTime()}</p>
        </div>

        {/* Loading animation */}
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <div
            className={`w-20 h-20 rounded-full ${currentStage.bgColor} flex items-center justify-center mb-6 animate-pulse`}
          >
            {currentStage.icon}
          </div>
          <p className={`text-center ${currentStage.color} mb-8 text-lg font-medium`}>{currentStage.message}</p>
          <div className="w-full max-w-md bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${currentStage.progress}%` }}
            ></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center mb-1">
          <button onClick={onBack} className="text-gray-500 mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m15 18-6-6 6-6" />
            </svg>
          </button>
          <h1 className="text-lg font-medium">New Session</h1>
        </div>
        <p className="text-xs text-gray-500">{getCurrentDateTime()}</p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab("prompt")}
          className={`flex items-center px-4 py-2 text-sm font-medium ${
            activeTab === "prompt" ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2"
          >
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
            <line x1="10" y1="9" x2="8" y2="9" />
          </svg>
          Prompt Text
        </button>
        <button
          onClick={() => setActiveTab("media")}
          className={`flex items-center px-4 py-2 text-sm font-medium ${
            activeTab === "media" ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2"
          >
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
          Media Files
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "prompt" && (
          <>
            {isEditing ? (
              // Edit Mode
              <div>
                {/* Formatting Toolbar */}
                <div className="flex items-center mb-3 space-x-2">
                  <button
                    onClick={() => applyFormatting("bold")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Bold"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
                      <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => applyFormatting("bullet")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Bullet List"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="8" y1="6" x2="21" y2="6" />
                      <line x1="8" y1="12" x2="21" y2="12" />
                      <line x1="8" y1="18" x2="21" y2="18" />
                      <line x1="3" y1="6" x2="3.01" y2="6" />
                      <line x1="3" y1="12" x2="3.01" y2="12" />
                      <line x1="3" y1="18" x2="3.01" y2="18" />
                    </svg>
                  </button>
                  <button
                    onClick={() => applyFormatting("number")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Numbered List"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="10" y1="6" x2="21" y2="6" />
                      <line x1="10" y1="12" x2="21" y2="12" />
                      <line x1="10" y1="18" x2="21" y2="18" />
                      <path d="M4 6h1v4" />
                      <path d="M4 10h2" />
                      <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
                    </svg>
                  </button>
                  <div className="flex-1"></div>
                  <button
                    onClick={handleSave}
                    className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md text-sm font-medium"
                    aria-label="Save"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    Save
                  </button>
                  <button
                    onClick={handleCancel}
                    className="flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md text-sm font-medium"
                    aria-label="Cancel"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                    Cancel
                  </button>
                </div>

                {/* Text Editor */}
                <textarea
                  ref={textareaRef}
                  id="prompt-editor"
                  className="w-full h-[500px] p-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm font-sans leading-relaxed"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  aria-label="Edit prompt text"
                />
              </div>
            ) : (
              // View Mode
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-gray-700 font-medium text-sm">Prompt Text</h3>
                  <div className="flex space-x-2">
                    <button
                      onClick={handleCopyText}
                      className="p-2 text-gray-500 hover:text-gray-700 relative"
                      aria-label="Copy to clipboard"
                      title="Copy to clipboard"
                    >
                      {copySuccess ? (
                        <span className="absolute -top-8 -left-2 bg-gray-800 text-white text-xs py-1 px-2 rounded">
                          Copied!
                        </span>
                      ) : null}
                      {copySuccess ? (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-green-500"
                        >
                          <path d="M20 6 9 17l-5-5" />
                        </svg>
                      ) : (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                        </svg>
                      )}
                    </button>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="p-2 text-gray-500 hover:text-gray-700"
                      aria-label="Edit text"
                      title="Edit text"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                      </svg>
                    </button>
                    <button
                      onClick={handleDelete}
                      className="p-2 text-red-500 hover:text-red-700"
                      aria-label="Delete session"
                      title="Delete session"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M3 6h18" />
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                        <line x1="10" y1="11" x2="10" y2="17" />
                        <line x1="14" y1="11" x2="14" y2="17" />
                      </svg>
                    </button>
                  </div>
                </div>

                {/* Formatted Text Display with typewriter effect */}
                <div className="whitespace-pre-wrap text-gray-800 prose max-w-none text-sm leading-relaxed">
                  {formatTextForDisplay(displayedText)}
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === "media" && <MediaFilesTab files={sampleMediaFiles} />}
      </div>

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-sm w-full p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-2">Delete this session?</h3>
            <p className="text-sm text-gray-500 mb-4">
              This will permanently delete this session and all associated media files. This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-2">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default NewSessionDetails
