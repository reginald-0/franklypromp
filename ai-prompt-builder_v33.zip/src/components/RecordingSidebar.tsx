"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"

interface RecordingSidebarProps {
  onCancel: () => void
  onComplete: () => void
  onScreenshot: () => void
  initialPosition?: "left" | "right" | "top" | "bottom"
}

const RecordingSidebar: React.FC<RecordingSidebarProps> = ({
  onCancel,
  onComplete,
  onScreenshot,
  initialPosition = "left",
}) => {
  const [recordingTime, setRecordingTime] = useState(0)
  const [isAnnotationActive, setIsAnnotationActive] = useState(false)
  const [showPositionMenu, setShowPositionMenu] = useState(false)
  const [position, setPosition] = useState<"left" | "right" | "top" | "bottom">(initialPosition)
  const [selectedTool, setSelectedTool] = useState<"pen" | "square" | "circle" | "eraser">("pen")
  const [selectedColor, setSelectedColor] = useState<"pink" | "green" | "blue" | "orange">("blue")
  const [audioLevels, setAudioLevels] = useState<number[]>([0.3, 0.5, 0.7, 0.4, 0.6, 0.3, 0.5, 0.2])
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // Colors for the annotation tools
  const colors = {
    pink: "#ec4899",
    green: "#10b981",
    blue: "#3b82f6",
    orange: "#f59e0b",
  }

  // Start the timer when component mounts
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setRecordingTime((prev) => prev + 1)
      // Simulate audio level changes
      setAudioLevels(
        Array(8)
          .fill(0)
          .map(() => Math.random() * 0.8 + 0.1),
      )
    }, 1000)

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Handle position change
  const changePosition = (newPosition: "left" | "right" | "top" | "bottom") => {
    setPosition(newPosition)
    setShowPositionMenu(false)
  }

  // Get sidebar position classes
  const getSidebarPositionClasses = () => {
    switch (position) {
      case "left":
        return "left-4 top-1/2 -translate-y-1/2 flex-col"
      case "right":
        return "right-4 top-1/2 -translate-y-1/2 flex-col"
      case "top":
        return "top-4 left-1/2 -translate-x-1/2 flex-row"
      case "bottom":
        return "bottom-4 left-1/2 -translate-x-1/2 flex-row"
      default:
        return "left-4 top-1/2 -translate-y-1/2 flex-col"
    }
  }

  // Determine if sidebar is vertical or horizontal
  const isVertical = position === "left" || position === "right"

  return (
    <div
      className={`fixed z-50 flex ${getSidebarPositionClasses()} bg-white rounded-xl shadow-lg transition-all duration-300`}
    >
      <div
        className={`flex ${isVertical ? "flex-col" : "flex-row"} items-center p-3 space-y-4 space-x-0 ${isVertical ? "" : "space-y-0 space-x-4"}`}
      >
        {/* Logo and Timer */}
        <div
          className={`flex ${isVertical ? "flex-col" : "flex-row"} items-center ${isVertical ? "space-y-2" : "space-x-3"}`}
        >
          <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
            FP
          </div>
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
            <span className="text-xs text-gray-600 mt-1">{formatTime(recordingTime)}</span>
          </div>
        </div>

        {/* Audio Visualization */}
        <div
          className={`flex ${isVertical ? "flex-col" : "flex-row"} items-center ${isVertical ? "space-y-1" : "space-x-1"} my-2`}
        >
          {audioLevels.map((_, index) => (
            <div
              key={index}
              className={`${isVertical ? "w-6 h-1" : "w-1 h-6"} bg-blue-500 opacity-70 rounded-full`}
            ></div>
          ))}
        </div>

        {/* Tool Controls */}
        <div className={`flex ${isVertical ? "flex-col" : "flex-row"} ${isVertical ? "space-y-3" : "space-x-3"}`}>
          {/* Drawing Tools Button */}
          <button
            onClick={() => setIsAnnotationActive(!isAnnotationActive)}
            className="w-10 h-10 rounded-full bg-white hover:bg-gray-100 flex items-center justify-center relative"
            aria-label="Toggle Drawing Tools"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={isAnnotationActive ? "text-indigo-600" : "text-gray-600"}
            >
              <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
              <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
              <path d="M2 2l7.586 7.586"></path>
              <circle cx="11" cy="11" r="2"></circle>
            </svg>
            {isAnnotationActive && (
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </div>
            )}
          </button>

          {/* Screenshot Button */}
          <button
            onClick={onScreenshot}
            className="w-10 h-10 rounded-full bg-white hover:bg-gray-100 flex items-center justify-center"
            aria-label="Take Screenshot"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
              <circle cx="12" cy="13" r="4"></circle>
            </svg>
          </button>

          {/* Position Button */}
          <button
            onClick={() => setShowPositionMenu(!showPositionMenu)}
            className="w-10 h-10 rounded-full bg-white hover:bg-gray-100 flex items-center justify-center"
            aria-label="Change Position"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <path d="M5 9l4-4 4 4"></path>
              <path d="M5 15l4 4 4-4"></path>
              <path d="M19 9l-4-4-4 4"></path>
              <path d="M19 15l-4 4-4-4"></path>
            </svg>
          </button>

          {/* Cancel Button */}
          <button
            onClick={onCancel}
            className="w-10 h-10 rounded-full bg-white hover:bg-gray-100 flex items-center justify-center"
            aria-label="Cancel Recording"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>

          {/* Complete Button */}
          <button
            onClick={onComplete}
            className="w-10 h-10 rounded-full bg-green-100 hover:bg-green-200 flex items-center justify-center"
            aria-label="Complete Recording"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-green-600"
            >
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
          </button>
        </div>

        {/* Annotation Tools Panel - Expanded vertically within the sidebar */}
        {isAnnotationActive && (
          <div className="flex flex-col items-center space-y-3 pt-2">
            {/* Pen Tool */}
            <button
              onClick={() => setSelectedTool("pen")}
              className={`w-10 h-10 rounded-md flex items-center justify-center ${
                selectedTool === "pen" ? "bg-indigo-600 text-white" : "bg-white text-gray-600"
              }`}
              aria-label="Pen Tool"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
                <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
              </svg>
            </button>

            {/* Square Tool */}
            <button
              onClick={() => setSelectedTool("square")}
              className={`w-10 h-10 rounded-md flex items-center justify-center ${
                selectedTool === "square" ? "bg-indigo-600 text-white" : "bg-white text-gray-600"
              }`}
              aria-label="Square Tool"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              </svg>
            </button>

            {/* Circle Tool */}
            <button
              onClick={() => setSelectedTool("circle")}
              className={`w-10 h-10 rounded-md flex items-center justify-center ${
                selectedTool === "circle" ? "bg-indigo-600 text-white" : "bg-white text-gray-600"
              }`}
              aria-label="Circle Tool"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10"></circle>
              </svg>
            </button>

            {/* Eraser Tool */}
            <button
              onClick={() => setSelectedTool("eraser")}
              className={`w-10 h-10 rounded-md flex items-center justify-center ${
                selectedTool === "eraser" ? "bg-indigo-600 text-white" : "bg-white text-gray-600"
              }`}
              aria-label="Eraser Tool"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 5H9l-7 7 7 7h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Z"></path>
                <path d="m18 9-6 6"></path>
                <path d="m12 9 6 6"></path>
              </svg>
            </button>

            {/* Color Selection */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSelectedColor("pink")}
                className={`w-5 h-5 rounded-full ${selectedColor === "pink" ? "ring-1 ring-gray-700" : ""}`}
                style={{ backgroundColor: colors.pink }}
                aria-label="Pink Color"
              ></button>
              <button
                onClick={() => setSelectedColor("green")}
                className={`w-5 h-5 rounded-full ${selectedColor === "green" ? "ring-1 ring-gray-700" : ""}`}
                style={{ backgroundColor: colors.green }}
                aria-label="Green Color"
              ></button>
              <button
                onClick={() => setSelectedColor("blue")}
                className={`w-5 h-5 rounded-full ${selectedColor === "blue" ? "ring-1 ring-gray-700" : ""}`}
                style={{ backgroundColor: colors.blue }}
                aria-label="Blue Color"
              ></button>
              <button
                onClick={() => setSelectedColor("orange")}
                className={`w-5 h-5 rounded-full ${selectedColor === "orange" ? "ring-1 ring-gray-700" : ""}`}
                style={{ backgroundColor: colors.orange }}
                aria-label="Orange Color"
              ></button>
            </div>
          </div>
        )}
      </div>

      {/* Position Menu */}
      {showPositionMenu && (
        <div
          className={`absolute ${position === "left" ? "left-full ml-2" : position === "right" ? "right-full mr-2" : position === "top" ? "top-full mt-2" : "bottom-full mb-2"} bg-white rounded-lg shadow-lg p-2`}
        >
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => changePosition("left")}
              className={`p-2 rounded-md ${position === "left" ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100"}`}
            >
              Left
            </button>
            <button
              onClick={() => changePosition("right")}
              className={`p-2 rounded-md ${position === "right" ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100"}`}
            >
              Right
            </button>
            <button
              onClick={() => changePosition("top")}
              className={`p-2 rounded-md ${position === "top" ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100"}`}
            >
              Top
            </button>
            <button
              onClick={() => changePosition("bottom")}
              className={`p-2 rounded-md ${position === "bottom" ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100"}`}
            >
              Bottom
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default RecordingSidebar
