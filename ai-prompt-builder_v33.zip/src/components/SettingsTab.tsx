"use client"

import type React from "react"
import { useState } from "react"

const SettingsTab: React.FC = () => {
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)

  // Sample user data
  const userData = {
    email: "user@example.com",
    plan: "Free Plan",
    userId: "A7X9B",
    credits: {
      used: 750,
      total: 2500,
      resetDays: 8,
    },
    storage: {
      totalFiles: 42,
      totalSize: "57.2 MB",
      audioFiles: 14,
      screenshots: 18,
      annotations: 10,
    },
  }

  // Calculate percentage for progress bar
  const creditPercentage = (userData.credits.used / userData.credits.total) * 100

  const handleDeleteAllFiles = () => {
    setShowConfirmDialog(true)
  }

  const confirmDelete = () => {
    // Logic to delete all files would go here
    setShowConfirmDialog(false)
    // You could add a success toast or message here
  }

  const cancelDelete = () => {
    setShowConfirmDialog(false)
  }

  return (
    <div className="flex flex-col h-full p-4">
      {/* User Profile Section */}
      <h2 className="text-blue-600 font-medium mb-3">User Profile</h2>
      <div className="bg-white rounded-lg border border-gray-200 p-4 mb-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-500"
            >
              <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-800 truncate">{userData.email}</p>
            <div className="flex items-center mt-1">
              <span className="bg-blue-100 text-blue-600 text-xs px-2 py-0.5 rounded-full mr-2">{userData.plan}</span>
              <span className="text-xs text-gray-500">ID: {userData.userId}</span>
            </div>
          </div>
        </div>

        {/* Credits Section */}
        <div className="mt-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-gray-700">Prompt Generation Credits</span>
            <span className="text-sm text-gray-700">
              {userData.credits.used} / {userData.credits.total}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-1">
            <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${creditPercentage}%` }}></div>
          </div>
          <p className="text-xs text-gray-500">Credits reset in {userData.credits.resetDays} days</p>
        </div>

        {/* Local Storage Section */}
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-700">Local Storage</span>
            <span className="text-sm text-gray-700">{userData.storage.totalSize}</span>
          </div>
          <p className="text-xs text-gray-500 mb-3">{userData.storage.totalFiles} Total Files</p>

          {/* File Type Breakdown */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="bg-blue-50 rounded p-2 text-center">
              <p className="text-blue-600 font-medium">{userData.storage.audioFiles}</p>
              <p className="text-xs text-blue-600">Audio</p>
            </div>
            <div className="bg-green-50 rounded p-2 text-center">
              <p className="text-green-600 font-medium">{userData.storage.screenshots}</p>
              <p className="text-xs text-green-600">Screenshots</p>
            </div>
            <div className="bg-purple-50 rounded p-2 text-center">
              <p className="text-purple-600 font-medium">{userData.storage.annotations}</p>
              <p className="text-xs text-purple-600">Annotations</p>
            </div>
          </div>

          {/* Delete All Button */}
          <button
            onClick={handleDeleteAllFiles}
            className="w-full bg-red-50 text-red-600 rounded-lg py-2 flex items-center justify-center hover:bg-red-100 transition-colors"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M3 6h18" />
              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
              <line x1="10" y1="11" x2="10" y2="17" />
              <line x1="14" y1="11" x2="14" y2="17" />
            </svg>
            Delete All Local Files
          </button>
        </div>
      </div>

      {/* External Account Links */}
      <div className="space-y-3">
        <a
          href="#"
          className="flex items-center justify-between bg-white rounded-lg border border-gray-200 p-4 hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-500 mr-3"
            >
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
            <span className="text-gray-700">Account Settings</span>
          </div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-400"
          >
            <path d="M7 7h10v10" />
            <path d="M7 17 17 7" />
          </svg>
        </a>

        <a
          href="#"
          className="flex items-center justify-between bg-white rounded-lg border border-gray-200 p-4 hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-500 mr-3"
            >
              <rect width="20" height="14" x="2" y="5" rx="2" />
              <line x1="2" x2="22" y1="10" y2="10" />
            </svg>
            <span className="text-gray-700">Subscription & Billing</span>
          </div>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-400"
          >
            <path d="M7 7h10v10" />
            <path d="M7 17 17 7" />
          </svg>
        </a>
      </div>

      {/* Confirmation Dialog */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-sm w-full p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-2">Delete all local files?</h3>
            <p className="text-sm text-gray-500 mb-4">
              This will permanently delete all your locally stored audio recordings, screenshots, and annotations. This
              action cannot be undone.
            </p>
            <div className="flex justify-end space-x-2">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Delete All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default SettingsTab
