"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import type { MediaFile } from "./MediaFilesTab"

interface ImageModalProps {
  file: MediaFile
  onClose: () => void
}

const ImageModal: React.FC<ImageModalProps> = ({ file, onClose }) => {
  const modalRef = useRef<HTMLDivElement>(null)

  // Close modal when clicking outside the image
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === modalRef.current) {
      onClose()
    }
  }

  // Close modal with escape key
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      }
    }

    document.addEventListener("keydown", handleEscKey)
    return () => {
      document.removeEventListener("keydown", handleEscKey)
    }
  }, [onClose])

  // Get title based on file type
  const getTitle = () => {
    return file.type.charAt(0).toUpperCase() + file.type.slice(1)
  }

  // Get color theme based on file type
  const getColorTheme = () => {
    if (file.type === "screenshot") {
      return "text-green-600"
    } else if (file.type === "annotation") {
      return "text-purple-600"
    }
    return "text-blue-600"
  }

  return (
    <div
      ref={modalRef}
      className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-lg max-w-4xl max-h-[90vh] w-full flex flex-col">
        {/* Modal header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className={`font-medium ${getColorTheme()}`}>
            {getTitle()}: {file.filename}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700" aria-label="Close">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Image container */}
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center">
          <img
            src={file.url || "/placeholder.svg"}
            alt={file.filename}
            className="max-w-full max-h-full object-contain"
            onError={(e) => {
              e.currentTarget.src = "/colorful-abstract-flow.png"
            }}
          />
        </div>
      </div>
    </div>
  )
}

export default ImageModal
