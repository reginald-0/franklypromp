"use client"

import type React from "react"

import { useState } from "react"
import AudioFileCard from "./AudioFileCard"
import ImageFileCard from "./ImageFileCard"
import ImageModal from "./ImageModal"

export type MediaFile = {
  id: string
  type: "audio" | "screenshot" | "annotation"
  filename: string
  filesize: string
  url: string
  duration?: string // For audio files
}

interface MediaFilesTabProps {
  files: MediaFile[]
}

const MediaFilesTab: React.FC<MediaFilesTabProps> = ({ files }) => {
  const [globalVolume, setGlobalVolume] = useState(0.7)
  const [isMuted, setIsMuted] = useState(false)
  const [selectedImage, setSelectedImage] = useState<MediaFile | null>(null)
  const [previousVolume, setPreviousVolume] = useState(0.7)

  // Handle volume change across all audio players
  const handleVolumeChange = (newVolume: number) => {
    setGlobalVolume(newVolume)
  }

  // Handle mute toggle across all audio players
  const handleMuteToggle = () => {
    if (!isMuted && globalVolume > 0) {
      // Store the current volume before muting
      setPreviousVolume(globalVolume)
    } else if (isMuted && previousVolume > 0) {
      // Restore the previous volume when unmuting
      setGlobalVolume(previousVolume)
    }
    setIsMuted(!isMuted)
  }

  // Open image modal
  const handleViewFullSize = (file: MediaFile) => {
    setSelectedImage(file)
  }

  // Close image modal
  const handleCloseModal = () => {
    setSelectedImage(null)
  }

  return (
    <div className="flex flex-col space-y-4 p-1">
      {files.length === 0 ? (
        <div className="text-center text-gray-500 py-8">
          <p>No media files available for this session.</p>
        </div>
      ) : (
        files.map((file) => {
          if (file.type === "audio") {
            return (
              <AudioFileCard
                key={file.id}
                file={file}
                volume={globalVolume}
                isMuted={isMuted}
                onVolumeChange={handleVolumeChange}
                onMuteToggle={handleMuteToggle}
              />
            )
          } else {
            return <ImageFileCard key={file.id} file={file} onViewFullSize={() => handleViewFullSize(file)} />
          }
        })
      )}

      {/* Full-size image modal */}
      {selectedImage && <ImageModal file={selectedImage} onClose={handleCloseModal} />}
    </div>
  )
}

export default MediaFilesTab
