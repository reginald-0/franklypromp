"use client"

import type React from "react"

import type { MediaFile } from "./MediaFilesTab"
import { useState } from "react"

interface ImageFileCardProps {
  file: MediaFile
  onViewFullSize: () => void
}

const ImageFileCard: React.FC<ImageFileCardProps> = ({ file, onViewFullSize }) => {
  const [imageError, setImageError] = useState(false)

  // Get color theme based on file type
  const getColorTheme = () => {
    if (file.type === "screenshot") {
      return {
        bg: "bg-green-50",
        text: "text-green-600",
        iconBg: "bg-green-100",
        buttonBg: "bg-green-100",
        buttonText: "text-green-700",
        buttonHover: "hover:bg-green-200",
      }
    } else {
      return {
        bg: "bg-purple-50",
        text: "text-purple-600",
        iconBg: "bg-purple-100",
        buttonBg: "bg-purple-100",
        buttonText: "text-purple-700",
        buttonHover: "hover:bg-purple-200",
      }
    }
  }

  const colors = getColorTheme()

  // Get icon based on file type
  const getIcon = () => {
    if (file.type === "screenshot") {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={colors.text}
        >
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>
      )
    } else {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={colors.text}
        >
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
        </svg>
      )
    }
  }

  // Placeholder for broken images
  const renderPlaceholder = () => (
    <div className="flex items-center justify-center h-full">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="48"
        height="48"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-gray-300"
      >
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <polyline points="21 15 16 10 5 21" />
      </svg>
    </div>
  )

  return (
    <div className={`${colors.bg} rounded-lg p-4`}>
      {/* File header */}
      <div className="flex items-center mb-3">
        <div className={`w-8 h-8 ${colors.iconBg} rounded flex items-center justify-center mr-2`}>{getIcon()}</div>
        <div className="flex-1">
          <div className="font-medium text-gray-800">{file.filename}</div>
          <div className="flex items-center text-sm">
            <span className={`${colors.text} mr-2`}>{file.type.charAt(0).toUpperCase() + file.type.slice(1)}</span>
            <span className="text-gray-500">{file.filesize}</span>
          </div>
        </div>
      </div>

      {/* Image preview */}
      <div className="bg-white border border-gray-200 rounded-lg p-1 mb-3 h-48 flex items-center justify-center overflow-hidden">
        {imageError ? (
          renderPlaceholder()
        ) : (
          <img
            src={file.url || "/placeholder.svg"}
            alt={file.filename}
            className="max-h-full max-w-full object-contain"
            onError={() => setImageError(true)}
          />
        )}
      </div>

      {/* View full size button */}
      <button
        onClick={onViewFullSize}
        className={`w-full ${colors.buttonBg} ${colors.buttonText} ${colors.buttonHover} py-2 rounded-lg flex items-center justify-center text-sm font-medium transition-colors`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="mr-1"
        >
          <path d="M15 3h6v6" />
          <path d="M10 14 21 3" />
          <path d="M9 21H3v-6" />
          <path d="M14 10 3 21" />
        </svg>
        View Full Size
      </button>
    </div>
  )
}

export default ImageFileCard
