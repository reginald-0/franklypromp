"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import type { MediaFile } from "./MediaFilesTab"

interface AudioFileCardProps {
  file: MediaFile
  volume: number
  isMuted: boolean
  onVolumeChange: (volume: number) => void
  onMuteToggle: () => void
}

const AudioFileCard: React.FC<AudioFileCardProps> = ({ file, volume, isMuted, onVolumeChange, onMuteToggle }) => {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)
  const progressRef = useRef<HTMLInputElement>(null)

  // Format time in MM:SS format
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`
  }

  // Handle play/pause toggle
  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  // Handle timeline scrubbing
  const handleTimelineChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = Number.parseFloat(e.target.value)
    setCurrentTime(newTime)
    if (audioRef.current) {
      audioRef.current.currentTime = newTime
    }
  }

  // Update audio element when volume or mute changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume
    }
  }, [volume, isMuted])

  // Set up audio event listeners
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime)
    }

    const handleLoadedMetadata = () => {
      setDuration(audio.duration)
    }

    const handleEnded = () => {
      setIsPlaying(false)
      setCurrentTime(0)
    }

    audio.addEventListener("timeupdate", handleTimeUpdate)
    audio.addEventListener("loadedmetadata", handleLoadedMetadata)
    audio.addEventListener("ended", handleEnded)

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate)
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata)
      audio.removeEventListener("ended", handleEnded)
    }
  }, [])

  return (
    <div className="bg-gray-100 rounded-lg p-4">
      {/* File header */}
      <div className="flex items-center mb-3">
        <div className="w-8 h-8 bg-blue-100 rounded flex items-center justify-center mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-blue-600"
          >
            <path d="M9 18V5l12-2v13" />
            <circle cx="6" cy="18" r="3" />
            <circle cx="18" cy="16" r="3" />
          </svg>
        </div>
        <div className="flex-1">
          <div className="font-medium text-gray-800">{file.filename}</div>
          <div className="flex items-center text-sm">
            <span className="text-blue-600 mr-2">Audio</span>
            <span className="text-gray-500">{file.filesize}</span>
          </div>
        </div>
      </div>

      {/* Audio element (hidden) */}
      <audio ref={audioRef} src={file.url} preload="metadata" />

      {/* Player controls */}
      <div className="flex flex-col space-y-3">
        {/* Play/pause button and timeline */}
        <div className="flex items-center space-x-3">
          <button
            onClick={togglePlayPause}
            className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300"
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="6" y="4" width="4" height="16" />
                <rect x="14" y="4" width="4" height="16" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
            )}
          </button>

          <div className="flex-1">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-blue-600">{formatTime(currentTime)}</span>
              <span className="text-gray-500">
                {formatTime(duration || (file.duration ? Number.parseFloat(file.duration) : 0))}
              </span>
            </div>
            <input
              ref={progressRef}
              type="range"
              min="0"
              max={duration || (file.duration ? Number.parseFloat(file.duration) : 0)}
              value={currentTime}
              onChange={handleTimelineChange}
              className="w-full h-1 bg-gray-300 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #3b82f6 ${(currentTime / (duration || 1)) * 100}%, #e5e7eb ${(currentTime / (duration || 1)) * 100}%)`,
              }}
              aria-label="Audio timeline"
            />
          </div>
        </div>

        {/* Volume controls */}
        <div className="flex items-center">
          <button
            onClick={onMuteToggle}
            className="text-gray-500 hover:text-gray-700 focus:outline-none mr-3"
            aria-label={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <line x1="23" y1="9" x2="17" y2="15" />
                <line x1="17" y1="9" x2="23" y2="15" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
              </svg>
            )}
          </button>

          <div className="w-1/2">
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={(e) => onVolumeChange(Number.parseFloat(e.target.value))}
              className="w-full h-1 bg-gray-300 rounded-full appearance-none cursor-pointer"
              style={{
                background: `repeating-linear-gradient(to right, #a855f7, #a855f7 2px, #ddd6fe 2px, #ddd6fe 4px) 0 / ${isMuted ? 0 : volume * 100}% 100% no-repeat, #e5e7eb`,
              }}
              aria-label="Volume"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default AudioFileCard
