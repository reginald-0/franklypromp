"use client"

import type React from "react"
import { useState } from "react"
import SessionCard from "./SessionCard"
import SessionDetails from "./SessionDetails"
import type { MediaFile } from "./media/MediaFilesTab"

const HistoryTab: React.FC = () => {
  const [selectedSession, setSelectedSession] = useState<{
    date: string
    duration: string
    content: string
    mediaFiles?: MediaFile[]
  } | null>(null)

  // Sample media files for demonstration
  const sampleMediaFiles: MediaFile[] = [
    {
      id: "audio-1",
      type: "audio",
      filename: "recording-1.mp3",
      filesize: "1.2 MB",
      url: "/sound-waves-abstract.png",
      duration: "0:02",
    },
    {
      id: "screenshot-1",
      type: "screenshot",
      filename: "screenshot-1.png",
      filesize: "345 KB",
      url: "/computer-screenshot.png",
    },
    {
      id: "annotation-1",
      type: "annotation",
      filename: "annotation-1.svg",
      filesize: "12 KB",
      url: "/annotated-manuscript.png",
    },
  ]

  // Sample history data - more comprehensive than the home tab
  const historySessions = [
    {
      date: "Today, 10:23 AM",
      duration: "2 min",
      content:
        "The navbar should have a gradient background that transitions smoothly from dark blue to light blue. The logo should be centered with navigation links evenly distributed on either side.",
      tags: ["Audio", "Annotated"],
      mediaFiles: sampleMediaFiles.slice(0, 2),
    },
    {
      date: "Yesterday, 3:45 PM",
      duration: "1 min",
      content: "Please change the button color to match our brand guidelines. The...",
      tags: ["Audio", "Screenshot"],
      mediaFiles: sampleMediaFiles.slice(0, 2),
    },
    {
      date: "Apr 23, 2:12 PM",
      duration: "30 sec",
      content: "The login form needs validation for email formats and password...",
      tags: ["Audio", "Screenshot", "Annotated"],
      mediaFiles: sampleMediaFiles,
    },
    {
      date: "Apr 21, 11:05 AM",
      duration: "3 min",
      content: "The dashboard chart colors need to be adjusted for better contrast. Also,...",
      tags: ["Audio", "Annotated"],
      mediaFiles: sampleMediaFiles.filter((file) => file.type !== "screenshot"),
    },
    {
      date: "Apr 18, 9:30 AM",
      duration: "5 min",
      content: "The user profile page should include a profile picture upload feature with cropping functionality...",
      tags: ["Audio", "Screenshot"],
      mediaFiles: sampleMediaFiles.slice(0, 2),
    },
    {
      date: "Apr 15, 2:45 PM",
      duration: "1 min",
      content: "The search functionality should include autocomplete suggestions based on previous searches...",
      tags: ["Audio"],
      mediaFiles: [sampleMediaFiles[0]],
    },
  ]

  if (selectedSession) {
    return (
      <SessionDetails
        sessionDate={selectedSession.date}
        sessionDuration={selectedSession.duration}
        promptText={selectedSession.content}
        mediaFiles={selectedSession.mediaFiles}
        onBack={() => setSelectedSession(null)}
      />
    )
  }

  return (
    <div className="flex flex-col h-full p-4">
      {/* Session History heading */}
      <h2 className="text-blue-600 font-medium mb-3">Session History</h2>

      {/* Session cards */}
      <div className="space-y-3 overflow-y-auto">
        {historySessions.map((session, index) => (
          <SessionCard
            key={index}
            date={session.date}
            duration={session.duration}
            content={session.content}
            tags={session.tags}
            onClick={() => setSelectedSession(session)}
          />
        ))}
      </div>
    </div>
  )
}

export default HistoryTab
