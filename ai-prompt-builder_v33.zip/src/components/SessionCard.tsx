"use client"

import type React from "react"

interface SessionCardProps {
  date: string
  duration: string
  content: string
  tags: string[]
  onClick: () => void
}

const SessionCard: React.FC<SessionCardProps> = ({ date, duration, content, tags, onClick }) => {
  const getTagColor = (tag: string) => {
    switch (tag) {
      case "Audio":
        return "bg-blue-100 text-blue-700"
      case "Screenshot":
        return "bg-green-100 text-green-700"
      case "Annotated":
        return "bg-purple-100 text-purple-700"
      default:
        return "bg-gray-100 text-gray-600"
    }
  }

  return (
    <div
      className="p-3 border border-gray-200 rounded-lg hover:shadow-md transition-shadow group relative cursor-pointer"
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-1">
        <span className="text-xs text-gray-600 whitespace-nowrap">
          {date} • {duration}
        </span>
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-400"
          >
            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
        </div>
      </div>
      <p className="text-sm text-gray-800 mb-2 line-clamp-2 leading-relaxed">{content}</p>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag, index) => (
          <span key={index} className={`text-xs px-2 py-0.5 rounded-full ${getTagColor(tag)}`}>
            {tag}
          </span>
        ))}
      </div>
    </div>
  )
}

export default SessionCard
