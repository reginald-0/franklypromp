"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import MediaFilesTab from "./media/MediaFilesTab"
import type { MediaFile } from "./media/MediaFilesTab"

interface SessionDetailsProps {
  sessionDate: string
  sessionDuration: string
  promptText: string
  mediaFiles?: MediaFile[]
  onBack: () => void
}

const SessionDetails: React.FC<SessionDetailsProps> = ({
  sessionDate,
  sessionDuration,
  promptText: initialPromptText,
  mediaFiles = [],
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<"prompt" | "media">("prompt")
  const [isEditing, setIsEditing] = useState(false)
  const [promptText, setPromptText] = useState(initialPromptText)
  const [editText, setEditText] = useState(initialPromptText)
  const [copySuccess, setCopySuccess] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Format text for display (handle bold, lists, etc.)
  const formatTextForDisplay = (text: string) => {
    // Process the text line by line
    return text.split("\n").map((line, index) => {
      // Handle bold text
      const formattedLine = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")

      // Check if line is a bullet list item
      if (line.trim().startsWith("- ")) {
        return (
          <li key={index} className="ml-5 list-disc">
            <span dangerouslySetInnerHTML={{ __html: formattedLine.substring(2) }} />
          </li>
        )
      }

      // Check if line is a numbered list item
      const numberedListMatch = line.trim().match(/^(\d+)\.\s(.*)/)
      if (numberedListMatch) {
        return (
          <li key={index} className="ml-5 list-decimal">
            <span dangerouslySetInnerHTML={{ __html: numberedListMatch[2] }} />
          </li>
        )
      }

      // Regular paragraph
      return (
        <p key={index} className="mb-4">
          <span dangerouslySetInnerHTML={{ __html: formattedLine }} />
        </p>
      )
    })
  }

  const handleCopyText = () => {
    navigator.clipboard.writeText(promptText)
    setCopySuccess(true)
    setTimeout(() => setCopySuccess(false), 2000)
  }

  const handleSave = () => {
    setPromptText(editText)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditText(promptText)
    setIsEditing(false)
  }

  const applyFormatting = (format: "bold" | "bullet" | "number") => {
    const textarea = textareaRef.current
    if (!textarea) return

    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = editText.substring(start, end)
    let formattedText = ""
    let cursorOffset = 0

    switch (format) {
      case "bold":
        formattedText = `**${selectedText}**`
        cursorOffset = 2
        break
      case "bullet":
        // If we're in the middle of a line, add a newline first
        const beforeSelection = editText.substring(0, start)
        const needsNewline = beforeSelection.length > 0 && !beforeSelection.endsWith("\n")
        formattedText = `${needsNewline ? "\n" : ""}- ${selectedText}`
        cursorOffset = needsNewline ? 3 : 2
        break
      case "number":
        // If we're in the middle of a line, add a newline first
        const beforeSelectionNum = editText.substring(0, start)
        const needsNewlineNum = beforeSelectionNum.length > 0 && !beforeSelectionNum.endsWith("\n")
        formattedText = `${needsNewlineNum ? "\n" : ""}1. ${selectedText}`
        cursorOffset = needsNewlineNum ? 4 : 3
        break
    }

    const newText = editText.substring(0, start) + formattedText + editText.substring(end)
    setEditText(newText)

    // Set focus back to textarea and position cursor
    setTimeout(() => {
      if (textarea) {
        textarea.focus()
        textarea.setSelectionRange(start + cursorOffset, start + cursorOffset + selectedText.length)
      }
    }, 0)
  }

  // Handle smart list continuation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter") {
      const textarea = textareaRef.current
      if (!textarea) return

      const cursorPos = textarea.selectionStart
      const textBeforeCursor = editText.substring(0, cursorPos)
      const textAfterCursor = editText.substring(cursorPos)

      // Check if we're in a bullet list
      const bulletListMatch = textBeforeCursor.match(/(?:^|\n)(- .*)$/)
      if (bulletListMatch) {
        const listItem = bulletListMatch[1]

        // If the list item is empty (just "- "), end the list
        if (listItem === "- " || listItem === "-") {
          e.preventDefault()
          const newText = textBeforeCursor.substring(0, textBeforeCursor.length - 2) + "\n" + textAfterCursor
          setEditText(newText)

          // Position cursor after the newline
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos - 1
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        } else {
          // Continue the list with a new bullet point
          e.preventDefault()
          const newText = textBeforeCursor + "\n- " + textAfterCursor
          setEditText(newText)

          // Position cursor after the new bullet point
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos + 3
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        }
        return
      }

      // Check if we're in a numbered list
      const numberedListMatch = textBeforeCursor.match(/(?:^|\n)(\d+)\. (.*)$/)
      if (numberedListMatch) {
        const listNumber = Number.parseInt(numberedListMatch[1])
        const listContent = numberedListMatch[2]

        // If the list item is empty, end the list
        if (listContent.trim() === "") {
          e.preventDefault()
          const newText =
            textBeforeCursor.substring(0, textBeforeCursor.length - (listNumber.toString().length + 2)) +
            "\n" +
            textAfterCursor
          setEditText(newText)

          // Position cursor after the newline
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos - (listNumber.toString().length + 1)
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        } else {
          // Continue the list with the next number
          e.preventDefault()
          const nextNumber = listNumber + 1
          const newText = textBeforeCursor + `\n${nextNumber}. ` + textAfterCursor
          setEditText(newText)

          // Position cursor after the new numbered item
          setTimeout(() => {
            if (textarea) {
              const newCursorPos = cursorPos + 3 + nextNumber.toString().length
              textarea.setSelectionRange(newCursorPos, newCursorPos)
            }
          }, 0)
        }
      }
    }
  }

  // Focus the textarea when entering edit mode
  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus()
    }
  }, [isEditing])

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center mb-1">
          <button onClick={onBack} className="text-gray-500 mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m15 18-6-6 6-6" />
            </svg>
          </button>
          <h1 className="text-lg font-medium">Session Details</h1>
        </div>
        <p className="text-xs text-gray-500">
          {sessionDate} • {sessionDuration}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab("prompt")}
          className={`flex items-center px-4 py-2 text-sm font-medium ${
            activeTab === "prompt" ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2"
          >
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
            <line x1="10" y1="9" x2="8" y2="9" />
          </svg>
          Prompt Text
        </button>
        <button
          onClick={() => setActiveTab("media")}
          className={`flex items-center px-4 py-2 text-sm font-medium ${
            activeTab === "media" ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="mr-2"
          >
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
          Media Files
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "prompt" && (
          <>
            {isEditing ? (
              // Edit Mode
              <div>
                {/* Formatting Toolbar */}
                <div className="flex items-center mb-3 space-x-2">
                  <button
                    onClick={() => applyFormatting("bold")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Bold"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
                      <path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => applyFormatting("bullet")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Bullet List"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="8" y1="6" x2="21" y2="6" />
                      <line x1="8" y1="12" x2="21" y2="12" />
                      <line x1="8" y1="18" x2="21" y2="18" />
                      <line x1="3" y1="6" x2="3.01" y2="6" />
                      <line x1="3" y1="12" x2="3.01" y2="12" />
                      <line x1="3" y1="18" x2="3.01" y2="18" />
                    </svg>
                  </button>
                  <button
                    onClick={() => applyFormatting("number")}
                    className="p-2 rounded hover:bg-gray-100"
                    aria-label="Numbered List"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="10" y1="6" x2="21" y2="6" />
                      <line x1="10" y1="12" x2="21" y2="12" />
                      <line x1="10" y1="18" x2="21" y2="18" />
                      <path d="M4 6h1v4" />
                      <path d="M4 10h2" />
                      <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
                    </svg>
                  </button>
                  <div className="flex-1"></div>
                  <button
                    onClick={handleSave}
                    className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md text-sm font-medium"
                    aria-label="Save"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    Save
                  </button>
                  <button
                    onClick={handleCancel}
                    className="flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md text-sm font-medium"
                    aria-label="Cancel"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                    Cancel
                  </button>
                </div>

                {/* Text Editor */}
                <textarea
                  ref={textareaRef}
                  id="prompt-editor"
                  className="w-full h-[500px] p-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm font-sans leading-relaxed"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  aria-label="Edit prompt text"
                />
              </div>
            ) : (
              // View Mode
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-gray-700 font-medium text-sm">Prompt Text</h3>
                  <div className="flex space-x-2">
                    <button
                      onClick={handleCopyText}
                      className="p-2 text-gray-500 hover:text-gray-700 relative"
                      aria-label="Copy to clipboard"
                    >
                      {copySuccess ? (
                        <span className="absolute -top-8 -left-2 bg-gray-800 text-white text-xs py-1 px-2 rounded">
                          Copied!
                        </span>
                      ) : null}
                      {copySuccess ? (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-green-500"
                        >
                          <path d="M20 6 9 17l-5-5" />
                        </svg>
                      ) : (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                        </svg>
                      )}
                    </button>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="p-2 text-gray-500 hover:text-gray-700"
                      aria-label="Edit text"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                      </svg>
                    </button>
                  </div>
                </div>

                {/* Formatted Text Display */}
                <div className="whitespace-pre-wrap text-gray-800 prose max-w-none text-sm leading-relaxed">
                  {formatTextForDisplay(promptText)}
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === "media" && <MediaFilesTab files={mediaFiles} />}
      </div>
    </div>
  )
}

export default SessionDetails
