"use client"

import type React from "react"
import { useState } from "react"
import SessionCard from "./SessionCard"
import SessionDetails from "./SessionDetails"
import NewSessionDetails from "./NewSessionDetails"
import RecordingOverlay from "./RecordingOverlay"
import type { MediaFile } from "./media/MediaFilesTab"

interface HomeTabProps {
  onNavigateToHistory?: () => void
}

const HomeTab: React.FC<HomeTabProps> = ({ onNavigateToHistory }) => {
  const [selectedSession, setSelectedSession] = useState<{
    date: string
    duration: string
    content: string
    mediaFiles?: MediaFile[]
  } | null>(null)
  const [showNewSession, setShowNewSession] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [isAnnotatingOnly, setIsAnnotatingOnly] = useState(false)

  // Sample media files for demonstration
  const sampleMediaFiles: MediaFile[] = [
    {
      id: "audio-1",
      type: "audio",
      filename: "recording-1.mp3",
      filesize: "1.2 MB",
      url: "/sound-waves-abstract.png",
      duration: "0:02",
    },
    {
      id: "screenshot-1",
      type: "screenshot",
      filename: "screenshot-1.png",
      filesize: "345 KB",
      url: "/computer-screenshot.png",
    },
    {
      id: "annotation-1",
      type: "annotation",
      filename: "annotation-1.svg",
      filesize: "12 KB",
      url: "/annotated-manuscript.png",
    },
  ]

  const sessions = [
    {
      date: "Today, 10:23 AM",
      duration: "2 min",
      content:
        "The navbar should have a gradient background that transitions smoothly from dark blue to light blue. The logo should be centered with navigation links evenly distributed on either side. Each link should have a subtle hover effect that enlarges the text slightly and changes its color to white.\n\nThe dropdown menus should appear with a fade-in animation and have slightly rounded corners. All buttons in the UI should maintain consistent styling with a 4px border radius and the primary action buttons should use our brand color #3B82F6.\n\nWhen users scroll down, the navbar should become slightly translucent, showing a hint of the content behind it, while maintaining readability of the navigation items.",
      tags: ["Audio", "Annotated"],
      mediaFiles: sampleMediaFiles,
    },
    {
      date: "Yesterday, 3:45 PM",
      duration: "1 min",
      content: "Please change the button color to match our brand guidelines. The...",
      tags: ["Audio", "Screenshot"],
      mediaFiles: sampleMediaFiles.slice(0, 2),
    },
    {
      date: "Apr 23, 2:12 PM",
      duration: "30 sec",
      content: "The login form needs validation for email formats and password...",
      tags: ["Audio", "Screenshot", "Annotated"],
      mediaFiles: sampleMediaFiles.slice(1),
    },
  ]

  // Handle starting a recording session
  const startRecording = (annotateOnly = false) => {
    setIsRecording(true)
    setIsAnnotatingOnly(annotateOnly)
  }

  // Handle canceling a recording
  const cancelRecording = () => {
    setIsRecording(false)
    setIsAnnotatingOnly(false)
  }

  // Handle completing a recording
  const completeRecording = () => {
    setIsRecording(false)
    setIsAnnotatingOnly(false)
    setShowNewSession(true)
  }

  // If recording is active, show only the recording overlay
  if (isRecording) {
    return <RecordingOverlay onCancel={cancelRecording} onComplete={completeRecording} />
  }

  // If showing new session details
  if (showNewSession) {
    return <NewSessionDetails onBack={() => setShowNewSession(false)} />
  }

  // If showing session details
  if (selectedSession) {
    return (
      <SessionDetails
        sessionDate={selectedSession.date}
        sessionDuration={selectedSession.duration}
        promptText={selectedSession.content}
        mediaFiles={selectedSession.mediaFiles}
        onBack={() => setSelectedSession(null)}
      />
    )
  }

  // Default home view
  return (
    <div className="flex flex-col h-full p-4">
      {/* Start a new session section */}
      <h2 className="text-blue-600 font-medium text-sm mb-3">Start a new session</h2>
      <div className="grid grid-cols-2 gap-3 mb-6">
        <button
          className="flex flex-col items-center justify-center p-4 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:shadow-md hover:scale-105 hover:brightness-105 hover:-translate-y-1 transition-all duration-200"
          onClick={() => startRecording(false)}
        >
          <div className="mb-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
              <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
              <line x1="12" y1="19" x2="12" y2="22"></line>
            </svg>
          </div>
          <span className="font-medium text-sm">Record</span>
          <span className="text-xs opacity-80 mt-1">Audio & Screen</span>
        </button>

        <button
          className="flex flex-col items-center justify-center p-4 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 text-white hover:shadow-md hover:scale-105 hover:brightness-105 hover:-translate-y-1 transition-all duration-200"
          onClick={() => startRecording(true)}
        >
          <div className="mb-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
              <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
              <path d="M2 2l7.586 7.586"></path>
              <circle cx="11" cy="11" r="2"></circle>
            </svg>
          </div>
          <span className="font-medium text-sm">Annotate Only</span>
          <span className="text-xs opacity-80 mt-1">Draw & Mark</span>
        </button>
      </div>

      {/* Recent Sessions section */}
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-blue-600 font-medium text-sm">Recent Sessions</h2>
        <div className="flex items-center">
          <button
            onClick={() => setShowNewSession(true)}
            className="flex items-center bg-amber-100 text-amber-700 px-2 py-1 rounded-md text-xs mr-2 font-medium"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M12 3v3m0 4.5V12m0 4.5V18"></path>
              <path d="M9 3h6"></path>
              <path d="M9 18h6"></path>
              <path d="M5.2 9h13.6"></path>
              <path d="M5.2 15h13.6"></path>
            </svg>
            New
          </button>
          <button onClick={onNavigateToHistory} className="text-blue-600 text-sm hover:underline font-medium">
            See all
          </button>
        </div>
      </div>

      {/* Session cards */}
      <div className="space-y-3">
        {sessions.map((session, index) => (
          <SessionCard
            key={index}
            date={session.date}
            duration={session.duration}
            content={session.content}
            tags={session.tags}
            onClick={() => setSelectedSession(session)}
          />
        ))}
      </div>
    </div>
  )
}

export default HomeTab
